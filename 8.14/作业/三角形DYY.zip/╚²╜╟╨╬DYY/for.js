for (var i=10;i>0;i--) {
    for (var j=1;j<i;j++) {
        document.write('*')
    }
    document.write('<br>')
}



    for (var i=1;i<=6;i++) {
        for (var j=6-i;j>=0;j--){
        document.write("&ensp;")
        }
        for(var n=1;n<=2*i-1;n++) {
            document.write("*")
        }
        document.write('<br>')
    }







