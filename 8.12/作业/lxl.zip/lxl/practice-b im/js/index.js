var searchOne = document.getElementById('searchOne');

var searchTwo = document.getElementById('searchTwo');


function lol() {
    var a = searchOne.value;
    var b = searchTwo.value;
    var c =(a/(b*b))*10000;
    alert(c)
}





