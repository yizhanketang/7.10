
var anyOne = parseInt(Math.random())+1
function rady() {
    var whatEver = document.getElementById('whatEver')

    if(whatEver.value > anyOne) {
        alert("It's to big")
    }

    if(whatEver.value < anyOne) {
        alert("It's to small")
    }

    if(whatEver.value == anyOne) {
        alert('biggo~~')
    }
}


// var sunny = parseInt(Math.random()*100+1)
//
// function rady() {
//     var flower = document.getElementById('flower')
//
//     if(flower.value > sunny) {
//         alert('太大了哟~')
//     }
//     if(flower.value < sunny) {
//         alert('太小了哟~')
//     }
//     if(flower.value == sunny) {
//         alert('waO~ 正确哟~')
//     }
// }















