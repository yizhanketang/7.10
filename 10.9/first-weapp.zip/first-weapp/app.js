App({
  onLaunch() {
    console.log('Launch')
  },
  onShow (options) {
    console.log('show')
  },
  globalData: {
    userInfo: null,
    username: 'guzoaho'
  }
})