$.ajax({
    url:'https://3g.163.com/touch/reconstruct/article/list/BA10TA81wangning/1-20.html',
    type: 'GET',
    dataType: 'jsonp',
    jsonpCallback: 'artiList',
    success: function (res) {
        console.log(res)
    }
});

// function loadXMLDoc() {
//     var xhttp = new XMLHttpRequest();
//     xhttp.onreadystatechange = function () {
//         if (this.readyState === 4 && this.status === 200){
//             myFunction(this);
//         }
//     }
//     xhttp.open("GET","https://3g.163.com/touch/reconstruct/article/list/BA10TA81wangning/1-20.html",true);
//     xhttp.send()
//     console.log(xhttp.send())
// };

