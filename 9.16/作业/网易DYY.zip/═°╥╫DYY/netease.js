$(function () {
    $('header a').on('click',function () {
        var $index = $(this).index()
        $(this).toggleClass('active').siblings().removeClass('active')
        $('section i').eq($index).addClass('active').siblings().removeClass('active')
    })
})