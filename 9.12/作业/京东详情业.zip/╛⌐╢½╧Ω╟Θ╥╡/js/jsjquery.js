$(function () {
    alert('aaaaaaaaaa')
})

