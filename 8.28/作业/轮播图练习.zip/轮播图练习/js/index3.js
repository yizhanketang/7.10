var content = document.querySelectorAll('.content');

allPlay(content[0], 4000,1200);
allPlay(content[1],2000,1000);

