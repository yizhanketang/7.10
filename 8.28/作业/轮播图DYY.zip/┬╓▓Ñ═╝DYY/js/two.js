var headerOne = document.getElementsByTagName('header');

plugIn(headerOne[0]);
plugIn(headerOne[1]);

// plugIn({
//     el:headerOne[0],
//     config:{
//         delay:3000
//     }
// });